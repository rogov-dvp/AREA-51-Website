<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Area 51 Gift Store</title>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" href="style/style.css"/>

</head>
<body>

<h1>Search for the products you want to buy:</h1>

<div class="site container-fluid">

	<nav class="navbar" id="filter">
		<form class="form-inline col-md-8" method="get" action="listprod.php">
			<div class="form-group col-md-8">
				<input class="form-control" id="searchFilter" type="text" name="productName" placeholder="Leave blank for all products"/>
		
			</div>
			<input type="submit" class="btn btn-primary" value="Submit"/>
			<input type="reset" class="btn btn-secondary" value="Reset"/>
		</form>

		<span id="cartPrompt">Shopping Cart</span>
		<i id="cart" class="material-icons">shopping_cart</i>
		

	</nav>


<?php
	include 'include/db_credentials.php';

	//session_start();

	$formSearch = "%";
	
	/** Get product name to search for **/
	if (isset($_GET['productName'])){
		$name = $_GET['productName'];
		$formSearch = $formSearch . $name . "%";
	}


	/** $name now contains the search string the user entered
	 Use it to build a query and print out the results. **/
	 
	/** Create and validate connection **/

	$con = sqlsrv_connect ($server, $connectionInfo);

	if ( $con == true ){
		echo '<script>console.log("Connection established")</script>';	
	} else {
		echo '<script>console.log("Connection not established")</script>';
		die( print_r( sqlsrv_errors(), true));
	}


	/** Print out the ResultSet **/
	$sqlQuery = "SELECT productId, productName, productPrice, categoryName FROM product JOIN category on category.categoryId = product.categoryId WHERE productName LIKE ?";



	$pstmt = sqlsrv_prepare($con, $sqlQuery, array(&$formSearch));
	if( !$pstmt ) {
	   die( print_r( sqlsrv_errors(), true));
   }

	$result = sqlsrv_execute($pstmt);
	if( $result === false ) {
		die( print_r( sqlsrv_errors(), true));
	}
	   
	echo("<table> <title>Stuff We Have</title>");

	while($row = sqlsrv_fetch_array ($pstmt, SQLSRV_FETCH_ASSOC)){
		$productId = $row['productId'];
		$productName = $row['productName'];
		$productPrice = $row['productPrice'];
		$categoryName = $row['categoryName'];

		echo("<tr><td><a href='addcart.php?id=" . $productId . "&name=" . $productName .  "&price=" . $productPrice . "'>Add to Cart</a></td>");
		echo("<td>" . $productName . "</td><td>" . $categoryName . "</td><td align=\"right\"> $" . $productPrice . "</td></tr>");



	
	/** 
	For each product create a link of the form
	addcart.php?id=<productId>&name=<productName>&price=<productPrice>
	Note: As some product names contain special characters, you may need to encode URL parameter for product name like this: urlencode($productName)
	**/

	}
	echo("</table>");
	/** Close connection **/
	sqlsrv_close($con);

	/**
        Useful code for formatting currency:
	       number_format(yourCurrencyVariableHere,2)
     **/
?>
</div>
</body>
</html>